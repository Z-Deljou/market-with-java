package com.coderschool.market.volleyserver;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Appjsonparse {
    String [] names;
    String [] imgurls;
    Integer [] prices;
    JSONArray apps=null;
    List<App> Apps;
    String json;

    public Appjsonparse(String json) {
        this.json = json;
    }
    public void parsejson(){
        JSONObject object = null;
        try {
            apps=new JSONArray(this.json);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        names=new String[apps.length()];
        imgurls=new String[apps.length()];
        prices=new Integer[apps.length()];
       Apps=new ArrayList<App>();
        for (int i=0;i<apps.length();i++){
            App app_model=new App();
            JSONObject object1= null;
            try {
                object1 = apps.getJSONObject(i);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                names[i]=object1.getString("name");
                imgurls[i]=object1.getString("icon");
                prices[i]=object1.getInt("price");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            app_model.setName(names[i]);
            app_model.setImage_url(imgurls[i]);
            app_model.setAppprice(prices[i]);
            Apps.add(app_model);
        }
    }
    public List<App> getApp(){
        return Apps;
    }
}
