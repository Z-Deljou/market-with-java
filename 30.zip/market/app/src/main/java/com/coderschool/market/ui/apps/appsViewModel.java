package com.coderschool.market.ui.apps;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class appsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public appsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is apps fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}