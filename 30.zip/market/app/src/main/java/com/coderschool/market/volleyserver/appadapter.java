package com.coderschool.market.volleyserver;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.coderschool.market.R;

import org.json.JSONObject;

import java.util.List;
import java.util.ResourceBundle;

public class appadapter extends RecyclerView.Adapter<appadapter.viewholder> {
    Context context;
    List<App> appdata;
    String iconurl="http://192.168.1.105:8080/mymarket/index.php/../assets/img/app/icon/";

    public appadapter(List<App> appdata) {
        this.appdata = appdata;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler, parent,false);
        viewholder viewholder=new viewholder(view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
holder.appname.setText(appdata.get(position).getName());
Integer prc=appdata.get(position).getAppprice();
        Glide.with(holder.iconimg.getContext()).load(iconurl+appdata.get(position).getImage_url()).into(holder.iconimg);
        if(prc==0){
            holder.appprice.setText("رایگان");
        }else {
            holder.appprice.setText("تومان"+prc.toString());
        }
    }

    @Override
    public int getItemCount() {
        return appdata.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        TextView appname,appprice;
        ImageView iconimg;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            appname=itemView.findViewById(R.id.appname);
            iconimg=itemView.findViewById(R.id.appicon);
            appprice=itemView.findViewById(R.id.appprice);
        }
    }
    public void add(int position,App item){
        appdata.add(position,item);
        notifyItemRemoved(position);

    }
}
