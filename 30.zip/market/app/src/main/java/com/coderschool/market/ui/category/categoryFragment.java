package com.coderschool.market.ui.category;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.coderschool.market.R;
import com.coderschool.market.volleyserver.App;
import com.coderschool.market.volleyserver.Appjsonparse;
import com.coderschool.market.volleyserver.appadapter;

import java.util.List;

public class categoryFragment extends Fragment {
private   String request_url="http://192.168.1.105:8080/mymarket/index.php/api/apprest/all/";
List <App> dataapp;
RecyclerView recyclerView;
RecyclerView.Adapter adapter;
RecyclerView.LayoutManager layoutManager;

    private categoryViewModel categoryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        categoryViewModel =
                ViewModelProviders.of(this).get(categoryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_category, container, false);

        categoryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {

            }
        });
        sendjsonreq();
        recyclerView=root.findViewById(R.id.appsrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager=new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(layoutManager);
        return root;
    }

    private void sendjsonreq() {
        StringRequest request=new StringRequest(request_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Appjsonparse appjsonparse =new Appjsonparse(response);
                appjsonparse.parsejson();
                dataapp=appjsonparse.getApp();
                adapter=new appadapter(dataapp);
                recyclerView.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error is:", error.toString());
            }
        });
        Volley.newRequestQueue(getContext()).add(request);
    }
}